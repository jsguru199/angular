export class Increment {
  static readonly type = '[counter] Increment';
}
