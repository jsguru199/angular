export interface CounterModel {
  value: number;
}
