import { Component } from '@angular/core';

@Component({
  selector: 'guide-pipes',
  template: `
    <sort-filter-list></sort-filter-list>
  `,
})
export class PipesComponent {}
